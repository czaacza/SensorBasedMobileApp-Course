package com.czaacza.locationandmapproject.ui.theme

import androidx.compose.ui.graphics.Color

val Purple200 = Color(0xFFB39DDB)
val Purple500 = Color(0xFF673AB7)
val Purple700 = Color(0xFF4527A0)
val Teal200 = Color(0xFF80CBC4)

val Orange200 = Color(0xFFFFCC80)
val Orange500 = Color(0xFFFF9800)
val Orange700 = Color(0xFFF57C00)

val Green200 = Color(0xFFA5D6A7)
val  Green500 = Color(0xFF4CAF50)
val  Green700 = Color(0xFF388E3C)
