package com.czaacza.materialdesignbasics.ui.theme

import androidx.compose.ui.graphics.Color

val Purple200 = Color(0xFFBB86FC)
val Purple500 = Color(0xFF6200EE)
val Purple700 = Color(0xFF3700B3)
val Teal200 = Color(0xFF03DAC5)

val Orange200 = Color(0xFFFFCC80)
val Orange500 = Color(0xFFFF9800)
val Orange700 = Color(0xFFF57C00)

val Green200 = Color(0xFFA5D6A7)
val  Green500 = Color(0xFF4CAF50)
val  Green700 = Color(0xFF388E3C)
