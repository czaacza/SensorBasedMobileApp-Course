package com.czaacza.retrofitwebapicallsproject.data.search

data class Continue(
    val `continue`: String,
    val sroffset: Int
)