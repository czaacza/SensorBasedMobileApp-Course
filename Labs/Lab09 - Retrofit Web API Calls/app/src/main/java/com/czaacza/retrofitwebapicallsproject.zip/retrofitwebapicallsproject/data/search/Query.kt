package com.czaacza.retrofitwebapicallsproject.data.search

data class Query(
    val search: List<Search>,
    val searchinfo: Searchinfo
)