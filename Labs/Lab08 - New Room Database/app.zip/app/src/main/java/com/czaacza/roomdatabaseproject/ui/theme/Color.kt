package com.czaacza.roomdatabaseproject.ui.theme

import androidx.compose.ui.graphics.Color

val Blue200 = Color(0xFF80DEEA)
val Blue500 = Color(0xFF00BCD4)
val Blue700 = Color(0xFF0097A7)
val Green200 = Color(0xFFC5E1A5)